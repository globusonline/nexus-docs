
"""
TODO: add a docstring.

"""

# We keep all initialization code in a separate module.

from pystache.init import render, Renderer, TemplateSpec

__all__ = ['render', 'Renderer', 'TemplateSpec']

__version__ = '0.5.2'  # Also change in setup.py.
