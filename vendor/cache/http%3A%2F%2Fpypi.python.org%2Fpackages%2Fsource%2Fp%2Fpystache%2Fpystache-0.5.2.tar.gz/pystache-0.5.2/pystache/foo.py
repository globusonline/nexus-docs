# coding: utf-8

"""
This module provides a Renderer class to render templates.

"""

import sys
#raise Exception("test: %s" % globals())

class Foo(object):

    def __init__(self):
        sys.stderr.write("***")
